# Agentic Eval Report

**Date**: 2026-03-10T22:13:04.385628+00:00
**Scenarios**: 0 passed / 1 total
**Categories**: happy-path

| Scenario | Category | System | Structural | Semantic | Overall | Time | Cost |
|---|---|---|---|---|---|---:|---|
| philosophy-bootstrap-from-user-source | happy-path | intent-bootstrap | PASS | FAIL | FAIL | 48.3s | Moderate |

## Failures
### philosophy-bootstrap-from-user-source
- AK1: PASS - The distilled philosophy contains P1 (script-owned workflow rails), P2 (upward signaling on ambiguity), and P3 (fail-closed corruption handling) - all three major rules from the user seed.
- AK2: PASS - All 6 principles (P1-P6) in the source map have source_type=user_source and source_file pointing to philosophy-source-user.md.
- AK3: FAIL - The bootstrap status shows blocking_state=NEEDS_PARENT and active_signal is set with a valid signal file path, indicating bootstrap signals remain active.
- AK4: FAIL - Signal file exists with required fields, but bootstrap_state is 'failed' not 'ready' as required.
